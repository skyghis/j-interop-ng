// TestServer2.cpp : Implementation of CTestServer2
#include "stdafx.h"
#include "TestJavaServer.h"
#include "TestServer2.h"
#include <comdef.h>
/////////////////////////////////////////////////////////////////////////////
// CTestServer2


STDMETHODIMP CTestServer2::Execute(BSTR message)
{
	
	int len;
	char message2[1024];
	len =WideCharToMultiByte(CP_ACP, 0,message, -1, NULL, 0, NULL, NULL);
	WideCharToMultiByte(CP_ACP, 0, message, -1, message2, len+1, NULL, NULL);
	MessageBoxEx(NULL,(const char*)message2,NULL,MB_OK,NULL);
	return S_OK;
}
