/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Tue Sep 26 14:16:20 2006
 */
/* Compiler settings for D:\TESTCODES\TestJavaServer\TestJavaServer.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __TestJavaServer_h__
#define __TestJavaServer_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ITestServer2_FWD_DEFINED__
#define __ITestServer2_FWD_DEFINED__
typedef interface ITestServer2 ITestServer2;
#endif 	/* __ITestServer2_FWD_DEFINED__ */


#ifndef __ITestServer1_FWD_DEFINED__
#define __ITestServer1_FWD_DEFINED__
typedef interface ITestServer1 ITestServer1;
#endif 	/* __ITestServer1_FWD_DEFINED__ */


#ifndef __TestServer1_FWD_DEFINED__
#define __TestServer1_FWD_DEFINED__

#ifdef __cplusplus
typedef class TestServer1 TestServer1;
#else
typedef struct TestServer1 TestServer1;
#endif /* __cplusplus */

#endif 	/* __TestServer1_FWD_DEFINED__ */


#ifndef __TestServer2_FWD_DEFINED__
#define __TestServer2_FWD_DEFINED__

#ifdef __cplusplus
typedef class TestServer2 TestServer2;
#else
typedef struct TestServer2 TestServer2;
#endif /* __cplusplus */

#endif 	/* __TestServer2_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __ITestServer2_INTERFACE_DEFINED__
#define __ITestServer2_INTERFACE_DEFINED__

/* interface ITestServer2 */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ITestServer2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("9CCC5120-457D-49F3-8113-90F7E97B54A7")
    ITestServer2 : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Execute( 
            BSTR message) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITestServer2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ITestServer2 __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ITestServer2 __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ITestServer2 __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ITestServer2 __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ITestServer2 __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ITestServer2 __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ITestServer2 __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Execute )( 
            ITestServer2 __RPC_FAR * This,
            BSTR message);
        
        END_INTERFACE
    } ITestServer2Vtbl;

    interface ITestServer2
    {
        CONST_VTBL struct ITestServer2Vtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITestServer2_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITestServer2_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITestServer2_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ITestServer2_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ITestServer2_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ITestServer2_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ITestServer2_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ITestServer2_Execute(This,message)	\
    (This)->lpVtbl -> Execute(This,message)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITestServer2_Execute_Proxy( 
    ITestServer2 __RPC_FAR * This,
    BSTR message);


void __RPC_STUB ITestServer2_Execute_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ITestServer2_INTERFACE_DEFINED__ */


#ifndef __ITestServer1_INTERFACE_DEFINED__
#define __ITestServer1_INTERFACE_DEFINED__

/* interface ITestServer1 */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ITestServer1;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("2A93A24D-59FE-4DE0-B67E-B8D41C9F57F8")
    ITestServer1 : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Call_TestServer2_Java( 
            ITestServer2 __RPC_FAR *ptr) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITestServer1Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ITestServer1 __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ITestServer1 __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ITestServer1 __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ITestServer1 __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ITestServer1 __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ITestServer1 __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ITestServer1 __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Call_TestServer2_Java )( 
            ITestServer1 __RPC_FAR * This,
            ITestServer2 __RPC_FAR *ptr);
        
        END_INTERFACE
    } ITestServer1Vtbl;

    interface ITestServer1
    {
        CONST_VTBL struct ITestServer1Vtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITestServer1_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITestServer1_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITestServer1_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ITestServer1_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ITestServer1_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ITestServer1_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ITestServer1_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ITestServer1_Call_TestServer2_Java(This,ptr)	\
    (This)->lpVtbl -> Call_TestServer2_Java(This,ptr)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITestServer1_Call_TestServer2_Java_Proxy( 
    ITestServer1 __RPC_FAR * This,
    ITestServer2 __RPC_FAR *ptr);


void __RPC_STUB ITestServer1_Call_TestServer2_Java_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ITestServer1_INTERFACE_DEFINED__ */



#ifndef __TESTJAVASERVERLib_LIBRARY_DEFINED__
#define __TESTJAVASERVERLib_LIBRARY_DEFINED__

/* library TESTJAVASERVERLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_TESTJAVASERVERLib;

EXTERN_C const CLSID CLSID_TestServer1;

#ifdef __cplusplus

class DECLSPEC_UUID("56BAD610-0FCB-418A-B25E-174159A4ADCE")
TestServer1;
#endif

EXTERN_C const CLSID CLSID_TestServer2;

#ifdef __cplusplus

class DECLSPEC_UUID("617D5A31-A3BF-440F-A58F-1F57F6AC7527")
TestServer2;
#endif
#endif /* __TESTJAVASERVERLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
