// TestServer2.h : Declaration of the CTestServer2

#ifndef __TESTSERVER2_H_
#define __TESTSERVER2_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CTestServer2
class ATL_NO_VTABLE CTestServer2 : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CTestServer2, &CLSID_TestServer2>,
	public IDispatchImpl<ITestServer2, &IID_ITestServer2, &LIBID_TESTJAVASERVERLib>
{
public:
	CTestServer2()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_TESTSERVER2)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CTestServer2)
	COM_INTERFACE_ENTRY(ITestServer2)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// ITestServer2
public:
	STDMETHOD(Execute)(BSTR message);
};

#endif //__TESTSERVER2_H_
