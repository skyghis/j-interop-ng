// TestClient.cpp : Defines the entry point for the application.
//

#include "stdafx.h"

#include "../TestJavaServer.h"
#include "../TestJavaServer_i.c"
#include <iostream.h>

// for showing possible mistakes
void ShowErrorMessage(LPCTSTR,HRESULT);

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	CoInitialize(NULL);

	IUnknown *ptrUnknown = NULL;
	ITestServer2 *ptrTestServer2 = NULL;
	ITestServer1 *ptrTestServer1 = NULL;
	HRESULT hr = CoCreateInstance(CLSID_TestServer1 , NULL, CLSCTX_LOCAL_SERVER, IID_IUnknown, (void**)&ptrUnknown);
	
	hr = ptrUnknown->QueryInterface(IID_ITestServer1, (void**)&ptrTestServer1);

	if (FAILED(hr))
	{
		cout << "Failed to create ITestServer1 instance, quitting";
	}
	else
	{
		ptrUnknown->Release();
		ptrUnknown = NULL;
		hr = CoCreateInstance(CLSID_TestServer2 , NULL, CLSCTX_LOCAL_SERVER, IID_IUnknown, (void**)&ptrUnknown);
		hr = ptrUnknown->QueryInterface(IID_ITestServer2, (void**)&ptrTestServer2);
		if (FAILED(hr))
		{
			cout << "Failed to create ITestServer2 instance, quitting";
		}

		ptrTestServer1->Call_TestServer2_Java(ptrTestServer2);
		ptrUnknown->Release();

	}

	if (ptrTestServer1)     
	{
		ptrTestServer1->Release();
	}

	if (ptrTestServer2)     
	{
		ptrTestServer2->Release();
	}


	
	CoUninitialize();
	return 0;
}


