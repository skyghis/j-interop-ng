// TestServer1.h : Declaration of the CTestServer1

#ifndef __TESTSERVER1_H_
#define __TESTSERVER1_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CTestServer1
class ATL_NO_VTABLE CTestServer1 : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CTestServer1, &CLSID_TestServer1>,
	public IDispatchImpl<ITestServer1, &IID_ITestServer1, &LIBID_TESTJAVASERVERLib>
{
public:
	CTestServer1()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_TESTSERVER1)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CTestServer1)
	COM_INTERFACE_ENTRY(ITestServer1)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// ITestServer1
public:
	STDMETHOD(Call_TestServer2_Java)(ITestServer2* ptr);
};

#endif //__TESTSERVER1_H_
