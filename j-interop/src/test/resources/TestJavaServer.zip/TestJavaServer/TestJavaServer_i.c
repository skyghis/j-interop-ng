/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Tue Sep 26 14:16:20 2006
 */
/* Compiler settings for D:\TESTCODES\TestJavaServer\TestJavaServer.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_ITestServer2 = {0x9CCC5120,0x457D,0x49F3,{0x81,0x13,0x90,0xF7,0xE9,0x7B,0x54,0xA7}};


const IID IID_ITestServer1 = {0x2A93A24D,0x59FE,0x4DE0,{0xB6,0x7E,0xB8,0xD4,0x1C,0x9F,0x57,0xF8}};


const IID LIBID_TESTJAVASERVERLib = {0x7B1A13E7,0x2ECB,0x4388,{0xBC,0xBB,0xD3,0x42,0x36,0xD0,0x51,0xED}};


const CLSID CLSID_TestServer1 = {0x56BAD610,0x0FCB,0x418A,{0xB2,0x5E,0x17,0x41,0x59,0xA4,0xAD,0xCE}};


const CLSID CLSID_TestServer2 = {0x617D5A31,0xA3BF,0x440F,{0xA5,0x8F,0x1F,0x57,0xF6,0xAC,0x75,0x27}};


#ifdef __cplusplus
}
#endif

