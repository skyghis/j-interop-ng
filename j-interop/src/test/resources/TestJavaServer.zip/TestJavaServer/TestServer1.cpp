// TestServer1.cpp : Implementation of CTestServer1
#include "stdafx.h"
#include "TestJavaServer.h"
#include "TestServer1.h"
#include <comdef.h>
/////////////////////////////////////////////////////////////////////////////
// CTestServer1


STDMETHODIMP CTestServer1::Call_TestServer2_Java(ITestServer2 *ptr)
{
	BSTR message = _bstr_t("Hello from COM Server: ITestServer1");
	ptr->Execute(message);
	return S_OK;
}
