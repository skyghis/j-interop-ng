// VBCollection.h : Declaration of the CVBCollection

#ifndef __VBCOLLECTION_H_
#define __VBCOLLECTION_H_

#include "resource.h"       // main symbols
#include <map>

// This typedef defines the internal STL storage collection
typedef std::map<CAdapt<CComBSTR>, CComVariant> VarMap;

// This copy policy copies items from the internal representation, 
// VarMap::iterator to the external representation, VARIANT
class _CopyVarMapToVariant
{
public:
	static HRESULT copy(VARIANT* pCopy, std::pair<const CAdapt<CComBSTR>, CComVariant>* pIt)
	{
		CComVariant v = pIt->second;
		v.Detach(pCopy);
		return S_OK;
	}
	static void init(VARIANT* p) {VariantInit(p);}
	static void destroy(VARIANT* p) {VariantClear(p);}
};


// This typedef will be derived from and provides a standard STL implementation
// for IEnumXXXX
typedef IEnumOnSTLImpl<IEnumVARIANT, &IID_IEnumVARIANT, VARIANT, _CopyVarMapToVariant, VarMap> VarEnumImpl;

/////////////////////////////////////////////////////////////////////////////
// CVBCollection
class ATL_NO_VTABLE CVBCollection : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CVBCollection, &CLSID_VBCollection>, // Comment this line and the line below to prevent creation
	public IDispatchImpl<IVBCollection, &IID_IVBCollection, &LIBID_STDCOLLECTIONLib>,
	public VarEnumImpl
{
public:
	CVBCollection() : nUniqueKeyCounter(0L) {}

DECLARE_REGISTRY_RESOURCEID(IDR_VBCOLLECTION) // Comment this line and the line above to prevent creation

DECLARE_NOT_AGGREGATABLE(CVBCollection)
DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CVBCollection)
	COM_INTERFACE_ENTRY(IVBCollection)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IEnumVARIANT)
END_COM_MAP()

public:
	virtual HRESULT FinalConstruct();

	// IVBCollection
	STDMETHOD(get__NewEnum)(IUnknown** pVal);
	STDMETHOD(get_Count)(long *pVal);
	STDMETHOD(Item)(	/* [in] */ VARIANT* Index, /* [out, retval] */ VARIANT* pvarRet);
	STDMETHOD(Add)(	/* [in] */ VARIANT* Item, /* [in, optional] */ VARIANT* Key);
	STDMETHOD(Remove)( /* [in] */ VARIANT* Index);

private:
	VarMap		m_coll;
	long		nUniqueKeyCounter;
};

#endif //__VBCOLLECTION_H_
