// VBCollection.cpp : Implementation of CVBCollection
#include "stdafx.h"
#include "StdCollection.h" // Include your ATL project's generated .h file here
#include "VBCollection.h"

///////////////////////////////////////////////////////////
// Helper Macros 
///////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////
// Wrap all interface methods in these macros to avoid 
// throwing an exception. Replace if better exception handling is
// required.
#define BEGIN_PROTECT_METHOD()		try {

#define END_PROTECT_METHOD()		} \
	/* Uncomment this if you are using any #import-ed objects \
	catch(_com_error e) \
	{ return e.Error(); } \
	*/ \
	catch(...) \
	{  return E_FAIL; }

///////////////////////////////////////////////////////////
// Use these macros to clear and test output parameters
#define CHECK_OUT_PARAM(p) \
	if(p) *p=0; else return E_POINTER

#define CHECK_OUT_PARAM_VARIANT(p) \
	if(p) VariantInit(p); else return E_POINTER

///////////////////////////////////////////////////////////
// Use this macro to test whether an optional VARIANT* is present or not
#define IS_OPTIONAL_VAR_PRESENT(pV) \
	((V_VT(pV) != VT_ERROR) && (V_ERROR(pV) != DISP_E_PARAMNOTFOUND))


///////////////////////////////////////////////////////////
// CVBCollection method implementations
///////////////////////////////////////////////////////////

HRESULT CVBCollection::FinalConstruct()
{
	BEGIN_PROTECT_METHOD();

	// Once we're constructed, call IEnumOnSTLImpl::Init()
	return Init(static_cast<IUnknown*>(static_cast<IDispatch*>(this)), m_coll);

	END_PROTECT_METHOD();
}

STDMETHODIMP CVBCollection::get__NewEnum(IUnknown** pVal)
{
	BEGIN_PROTECT_METHOD();
	CHECK_OUT_PARAM(pVal);

	// Make sure the internal STL iterator is at the beginning
	// by calling IEnumVARIANT::Reset()
	Reset();

	// Cast back to IUnknown*
	*pVal = static_cast<IUnknown*>(static_cast<IEnumVARIANT*>(this));
	(*pVal)->AddRef();

	return S_OK;

	END_PROTECT_METHOD();
}

STDMETHODIMP CVBCollection::get_Count(long *pVal)
{
	BEGIN_PROTECT_METHOD();
	CHECK_OUT_PARAM(pVal);

	*pVal = m_coll.size();
	return S_OK;

	END_PROTECT_METHOD();
}

STDMETHODIMP CVBCollection::Item(VARIANT* Index, VARIANT* pVal)
{
	BEGIN_PROTECT_METHOD();
	CHECK_OUT_PARAM_VARIANT(pVal);

	// According to the VB documentation Index must 
	// either be numeric or a string
	if( V_VT(Index) == VT_BSTR )
	{
		CComBSTR bstrKey( V_BSTR(Index) );
		VarMap::iterator it = m_coll.find(bstrKey);
		_CopyVarMapToVariant::copy(pVal, &(*it));
	}
	else if( (V_VT(Index) == VT_I2))
	{
		short nIndex = V_I2(Index);
		VarMap::iterator it = m_coll.begin();
		VarMap::iterator end = m_coll.end();

		for( int i=0; i<nIndex && it != end; i++, it++ ) ;

		if( it == end )	// We got to the end without finding it
			return E_FAIL;
		else
			_CopyVarMapToVariant::copy(pVal, &(*it));
	}
	else if( (V_VT(Index) == VT_I4))
	{
		long nIndex = V_I2(Index);
		VarMap::iterator it = m_coll.begin();
		VarMap::iterator end = m_coll.end();

		for( int i=0; i<nIndex && it != end; i++, it++ ) ;

		if( it == end )	// We got to the end without finding it
			return E_FAIL;
		else
			_CopyVarMapToVariant::copy(pVal, &(*it));
	}
	else
		return E_INVALIDARG;

	return S_OK;

	END_PROTECT_METHOD();
}

STDMETHODIMP CVBCollection::Add( /* [in] */ VARIANT* Item, /* [in, optional] */ VARIANT* Key)
{
	BEGIN_PROTECT_METHOD();

	CComVariant varAdded(*Item);
	CComBSTR bstrKey;

	// Determine if the optional param Key is present
	if( IS_OPTIONAL_VAR_PRESENT(Key) )
	{
		// According to the VB documentation, key must be a string
		if( V_VT(Key) == VT_BSTR )
			bstrKey = V_BSTR(Key);
		else
			return E_INVALIDARG;
	}
	else
	{
		// We don't have a key, so make one from the next unique counter
		TCHAR szKey[128];
		wsprintf(szKey, "Key_%li", nUniqueKeyCounter++);
		bstrKey = szKey;
	}

	m_coll[bstrKey] = varAdded;

	return S_OK;
	
	END_PROTECT_METHOD();
}

STDMETHODIMP CVBCollection::Remove( /* [in] */ VARIANT* Index)
{
	BEGIN_PROTECT_METHOD();

	// According to the VB documentation Index must 
	// either be numeric or a string. I'll assume they mean
	// only VT_I4 or VT_I2

	if( V_VT(Index) == VT_BSTR )
	{
		CComBSTR bstrKey( V_BSTR(Index) );
		m_coll.erase(bstrKey);
	}
	else if( (V_VT(Index) == VT_I2))
	{
		short nIndex = V_I2(Index);
		VarMap::iterator it = m_coll.begin();
		VarMap::iterator end = m_coll.end();

		for( int i=0; i<nIndex && it != end; i++, it++ ) ;

		if( it == end )	// We got to the end without finding it
			return E_FAIL;
		else
			m_coll.erase(it);
	}
	else if( (V_VT(Index) == VT_I4))
	{
		long nIndex = V_I2(Index);
		VarMap::iterator it = m_coll.begin();
		VarMap::iterator end = m_coll.end();

		for( int i=0; i<nIndex && it != end; i++, it++ ) ;

		if( it == end )	// We got to the end without finding it
			return E_FAIL;
		else
			m_coll.erase(it);
	}
	else
		return E_INVALIDARG;

	return S_OK;

	END_PROTECT_METHOD();
}

// Just in case
#undef IS_OPTIONAL_VAR_PRESENT
#undef CHECK_OUT_PARAM
#undef BEGIN_PROTECT_METHOD
#undef END_PROTECT_METHOD
