//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SampleTestServer.rc
//
#define IDS_PROJNAME                    100
#define IDR_TestServer                  101
#define IDD_TESTSERVERSQDLG		        103
#define IDC_EDIT1                       203
#define IDB_BITMAP1                     203

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        204
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         204
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
