// TesetServer.h : Declaration of the CTestServer

#ifndef __TESTSERVER_H_
#define __TESTSERVER_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CTestServer
class ATL_NO_VTABLE CTestServer :
//	public CComObjectRootEx<CComSingleThreadModel>,
    public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CTestServer, &CLSID_TestServer>,
	public ITestServer
{
public:
	CTestServer()
	{
		InitializeCriticalSection(&m_criticalsection);
	}
	~CTestServer()
	{
		DeleteCriticalSection(&m_criticalsection);
	}

public:
	short val;
	/*static*/ CRITICAL_SECTION m_criticalsection;



DECLARE_REGISTRY_RESOURCEID(IDR_TestServer)
DECLARE_NOT_AGGREGATABLE(CTestServer)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CTestServer)
	COM_INTERFACE_ENTRY(ITestServer)
END_COM_MAP()

// ITestServer
public:
	STDMETHOD(AskTestServerToSquareNumber)();
	STDMETHOD(TestServerSquare)(/*[in]*/ short num,/*[out,retval]*/ short *numsqr);
	STDMETHOD(SayHi)();

   STDMETHOD(DoSomethingAndGetSomethingBack)(
			ICallbackTestServer *pparam,
			long *sid);
   STDMETHOD(CallSimpleCallback)(/*[in]*/ ICallbackTestServer *pparam,
								/*[out]*/ long *sid);

   STDMETHOD(UnDoSomethingAndGetSomethingBack)(/* [in] */ long lSessionID,
								/* [out,ref]*/ unsigned long* pSessionId);

	STDMETHOD (GetTCharArray)(/*[out]*/ TCHAR* tcharArray[50]);

	STDMETHOD (SetTCharArray)(/*[in]*/ TCHAR tcharArray[50]);

	STDMETHOD (GetConformantIntArray)(/*[out]*/ int* sizeOut, /*[out, size_is(,*sizeOut)]*/ int** intArray);

	STDMETHOD (SetConformantIntArray)(/*[in]*/ int size,/*[in, size_is(size)]*/ int intArray[]);

	STDMETHOD (GetStruct)(/*[out]*/ stStructA** param);

	STDMETHOD (SetStruct)(/*[in]*/ stStructA param);

	STDMETHOD (GetSimpleStruct)(/*[out]*/ SimpleStruct** ppSimpleStruct);

	STDMETHOD (GetConformantStructArray)(unsigned short* isize,
										/*[out]*/ SimpleStruct** ppSimpleStruct);

	STDMETHOD (GetConformantStruct)(/*[out]*/ ConformantStruct** ppConformantStruct);

	STDMETHOD (GetStructArray)(/*[out]*/ unsigned short* length,
									/*[out, size_is(length)]*/ struct StructC** pparam);

	STDMETHOD (SetStructArray)(/*[in]*/ unsigned short length,
									/*[in, size_is(length)]*/ struct StructC * pparam);

	STDMETHOD (GetStructStruct)(StructStruct** pp);

	STDMETHOD (GetStructStructArray)(unsigned short* isize,StructStruct** pp);

	STDMETHOD (GetSimpleArrayStruct)(SimpleArrayStruct** pp);

	STDMETHOD (GetSimpleArrayStructArray)(unsigned short* isize,SimpleArrayStruct** pp);

	STDMETHOD (SetSimpleArrayStructArray)(unsigned short isize,SimpleArrayStruct* pp);

	STDMETHOD (GetStructArray2)(/*[out]*/ unsigned short* length,
									/*[out, size_is(length)]*/ struct StructC** p);

	STDMETHOD (SetStructArray2)(/*[in]*/ unsigned short length,
									/*[in, size_is(length)]*/ struct StructC* p);
};

#endif //__TestServer_H_
