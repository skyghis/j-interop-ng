// TestServer.cpp : Implementation of ITestServer
#include <iostream>
#include "stdafx.h"
#include "SampleTestServer.h"
#include "TestServer.h"
#include "TestServerSQDLG.h"
#include <comdef.h>
#include <comutil.h>


#ifndef MIDL_DEFINE_GUID
#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        const type name = {l,w1,w2,{b1,b2,b3,b4,b5,b6,b7,b8}}
#endif

MIDL_DEFINE_GUID(IID, IID_ICallbackTestServer,0x88CA8731,0x78CE,0x11d2,0x8E,0xE4,0x00,0x60,0x08,0x1C,0x52,0xE3);


/////////////////////////////////////////////////////////////////////////////
// CTestServer


STDMETHODIMP CTestServer::SayHi()
{
	// TODO: Add your implementation code here

	MessageBox(NULL, "Yo !", "Hi!", MB_OK);

	return S_OK;
}


STDMETHODIMP CTestServer::TestServerSquare(short num, short *numsqr)
{
	// TODO: Add your implementation code here
	//val = atoi(tnum);
	short val = num;
	val*=val;
	*numsqr=val;
	return S_OK;
}

STDMETHODIMP CTestServer::AskTestServerToSquareNumber()
{
	// TODO: Add your implementation code here
	BSTR bval;
	char *tmpstr;
	char tnum[50];
	val=0;
	CTestServerSQDLG md;

	md.DoModal();

	bval = md.mnum.m_str;

//	tmpstr = new char[50];
	tmpstr = _com_util::ConvertBSTRToString(bval);

    strncpy(tnum,tmpstr,10);
	val = atoi(tnum);

	val*=val;

	sprintf(tmpstr,"Your number squared is %d.",val);

	MessageBox(NULL,tmpstr, "Server Reply!", MB_OK);


	return S_OK;
}

DWORD ThreadMsgWaitForSingleObject (HANDLE hHandle, DWORD dwMilliseconds)
{
  HANDLE	dwChangeHandles[1] = { hHandle };
  DWORD		dwWaitStatus = 0;
  DWORD		dwRet = 0;
  bool		bContinueLoop = true;

  // Msg Loop while waiting for hHandle to be signaled.
  while (bContinueLoop)
  {
    // Wait for notification.
    dwWaitStatus = ::MsgWaitForMultipleObjectsEx
	(
      (DWORD)1,          // number of handles in array
      dwChangeHandles, // object-handle array
      (DWORD)dwMilliseconds,  // time-out interval
      (DWORD)(QS_ALLINPUT | QS_ALLPOSTMESSAGE),      // input-event type
      (DWORD)(MWMO_INPUTAVAILABLE)          // wait options
    );

    switch (dwWaitStatus)
    {
      // First wait (hHandle) object has been signalled.
	  case WAIT_OBJECT_0 :
	  {
	    dwRet = dwWaitStatus;
        // Flag to indicate stop loop.
		bContinueLoop = false;
	    break;
	  }

      // Windows message has arrived.
      case WAIT_OBJECT_0 + 1:
	  {
	    MSG msg;

        // Dispatch all windows messages in queue.
	    while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
	    {
	      TranslateMessage (&msg);
		  DispatchMessage(&msg);
	    }

	    break;
	  }

      // Timeout has elapsed.
	  case WAIT_TIMEOUT :
	  {
	    dwRet = dwWaitStatus;
        // Flag to indicate stop loop.
		bContinueLoop = false;
	    break;
	  }

      default:
	  {
	    break;
	  }
    }
  }

  return dwRet;
}
static LPGLOBALINTERFACETABLE pGIT = NULL;
static CRITICAL_SECTION* pCriticalsection;

LRESULT CallbackThreadProc(LPARAM lParam)
{
	DWORD cookie = (DWORD)lParam;
    HRESULT hr;
	LPGLOBALINTERFACETABLE pLocalGIT = NULL;
	FILE *fp;
	if( (fp=fopen("C:\\Test\\TestServer_thread.log" , "at+")) == NULL ){
		return MK_E_CANTOPENFILE;
	}

	fprintf(fp, "CTestServer::DoSomethingAndGetSomethingBack:CallbackThreadProc entered\n");

	// Initialize COM for use by this thread. Tell COM this new thread
    // is another free-threaded thread in the multi-threaded apartment.
	EnterCriticalSection(pCriticalsection);
	hr = CoInitializeEx(NULL,COINIT_APARTMENTTHREADED);
	//hr = CoInitializeEx(NULL,COINIT_MULTITHREADED);

	fprintf(fp, "CallbackThreadProc::GIT created\n");
	// create Global Interface Table(GIT)
	hr = CoCreateInstance(CLSID_StdGlobalInterfaceTable, NULL, CLSCTX_INPROC_SERVER,
							IID_IGlobalInterfaceTable, (LPVOID*)&pLocalGIT);
	if (!SUCCEEDED(hr))
	{
		fprintf(fp, "CallbackThreadProc::FATAL ERROR , UNABLE TO INITIALIZE GIT !!! 0x%x\n", hr);
		CoUninitialize();  //Uninitialize the COM library
		LeaveCriticalSection(pCriticalsection);
		fclose(fp);
		return hr;
	}

	if (hr == S_OK)
		fprintf(fp, "CallbackThreadProc::CoInitializeEx success\n");
	//we take the pointer from GIT and use that to set the status
	ICallbackTestServer *pparamFromGIT;
	// get proxy to interface from GIT
	hr = pLocalGIT->GetInterfaceFromGlobal(cookie, IID_ICallbackTestServer, (LPVOID*)&pparamFromGIT);
	if ( !SUCCEEDED(hr) )
	{
		fprintf(fp, "CallbackThreadProc::GetInterfaceFromGlobal VERY ERRONEOUS SCENARIO !!!! COULD NOT GET INFORMATION FROM GIT!!!  0x%x\n", hr);
		CoUninitialize();  //Uninitialize the COM library
		LeaveCriticalSection(pCriticalsection);
		fclose(fp);
		return hr;
	}

	//Make one call to the other guy synchronously for starters
	ICallbackTestServer *pCallbackTestServer;
	if (pparamFromGIT != NULL){
		hr=pparamFromGIT->QueryInterface(IID_ICallbackTestServer,(void**) &pCallbackTestServer);
		if (hr != S_OK){
			fprintf(fp, "CTestServer::DoSomethingAndGetSomethingBack:CallbackThreadProc ==> failed to query interface HR=0x%x\n", hr);
			CoUninitialize();  //Uninitialize the COM library
			LeaveCriticalSection(pCriticalsection);
			fclose(fp);
			return hr;
		}
	}

	fprintf(fp, "CallbackThreadProc::GetInterfaceFromGlobal success\n");
	unsigned short size = 2;
	stStructA* Data = new stStructA[size];
	for (int i=0; i<3; i++){
		// TODO: Add your implementation code here
		for(int j=0; j<50; j++){
			Data[0].param3[j] = i+6;
			Data[1].param3[j] = i+7;
		}
		Data[0].param1 = 300;
		Data[0].param2 = 2.0;
		Data[1].param1 = 301;
		Data[1].param2 = 2.1;
		fprintf(fp, "CTestServer::InvokeCallback:CallbackThreadProc ==> Sending 2 back\n");
		//pCallbackTestServer->UpdateStructC(i, size, Data);
		pparamFromGIT->UpdateStructC(i, size, Data);
		fprintf(fp, "CTestServer::InvokeCallback:CallbackThreadProc ==> pparam->UpdateStructC returned\n");
		Sleep(5000);
	}
	pCallbackTestServer->Release();
	//pparamFromGIT->Release();

     // UnInitialize COM for use by this thread.
	if (pLocalGIT)
		pLocalGIT -> Release();
	CoUninitialize();  //Uninitialize the COM library
	LeaveCriticalSection(pCriticalsection);
	fprintf(fp, "CTestServer::CallbackThreadProc returning\n");
	fclose(fp);
	return hr;
}

STDMETHODIMP CTestServer::DoSomethingAndGetSomethingBack(ICallbackTestServer *pparam, long *sid)
{
	HRESULT hr = S_OK;
	long session = 7;
	*sid = session;
	DWORD gdwCookie = 0;
	if (pCriticalsection == NULL)
		pCriticalsection = &m_criticalsection;

	FILE *fp;
	if( (fp=fopen("C:\\Test\\TestServer.log" , "at+")) != NULL )
	{
		fprintf(fp, "CTestServer::DoSomethingAndGetSomethingBack ==> entered\n", hr);
		ICallbackTestServer *pCallbackTestServer;
		//Make one call to the other guy synchronously for starters
		if (pparam != NULL){
			HRESULT hr=pparam->QueryInterface(IID_ICallbackTestServer,(void**) &pCallbackTestServer);
			if (hr != S_OK){
				fprintf(fp, "CTestServer::DoSomethingAndGetSomethingBack ==> failed to query interface HR=0x%x\n", hr);
				return hr;
			}
			// TODO: Add your implementation code here
			unsigned short size = 2;
			stStructA* Data = new stStructA[size];
			for(int j=0; j<50; j++)
				Data[0].param3[j] = 7;
	
			Data[0].param1 = 300;
			Data[0].param2 = 2.0;
	
			for(int j=0; j<50; j++)
				Data[1].param3[j] = 10;
			Data[1].param1 = 301;
			Data[1].param2 = 2.1;
			fprintf(fp, "CTestServer::DoSomethingAndGetSomethingBack ==> Sending 2 back\n");
			pCallbackTestServer->UpdateStructC(session, size, Data);
			pCallbackTestServer->Release();
			fprintf(fp, "CTestServer::DoSomethingAndGetSomethingBack ==> pparam->UpdateStructC came back\n");
		}

		if (pGIT == NULL)
		{
			fprintf(fp, "CTestServer::GIT created\n");
			// create Global Interface Table(GIT)
			hr = CoCreateInstance(CLSID_StdGlobalInterfaceTable, NULL, CLSCTX_INPROC_SERVER,
									IID_IGlobalInterfaceTable, (LPVOID*)&pGIT);
			if (!SUCCEEDED(hr))
			{
				fprintf(fp, "CTestServer::FATAL ERROR , UNABLE TO INITIALIZE GIT !!! 0x%x\n", hr);
				CoUninitialize();  //Uninitialize the COM library
				fclose(fp);
				return hr;
			}
		}

		if (gdwCookie == 0){
			EnterCriticalSection(pCriticalsection);
			hr = pGIT->RegisterInterfaceInGlobal(pparam,IID_ICallbackTestServer,&gdwCookie);
			LeaveCriticalSection(pCriticalsection);
			if ( !SUCCEEDED(hr) )
			{
				fprintf(fp, "CTestServer::FATAL ERROR , COULD NOT REGISTER WITH GIT 0x%x\n", hr);
				CoUninitialize();  //Uninitialize the COM library
				fclose(fp);
				return hr;
			}
			fprintf(fp, "CTestServer::RegisterInterfaceInGlobal success\n");
		}

		// create the thread suspended so its event can be created using its thread-id and it will be able to
		// use it as soon as it runs
		DWORD   dwClienttid;
		fprintf(fp, "CTestServer::DoSomethingAndGetSomethingBack ==> created new thread to start async calls\n");
		HANDLE hClientThread = CreateThread(NULL,
			(SIZE_T)0,
			(LPTHREAD_START_ROUTINE)&CallbackThreadProc,
			(LPVOID)gdwCookie,
			(DWORD)0,
			(LPDWORD)&dwClienttid);
		if (hClientThread == NULL){
			hr = S_FALSE;
			fprintf(fp, "CTestServer::CreateThread failed\n");
			fclose(fp);
			return hr;
		}

		//Sleep(90000);
		ThreadMsgWaitForSingleObject(hClientThread, INFINITE);
		CloseHandle (hClientThread);
		hClientThread = NULL;
		pGIT -> RevokeInterfaceFromGlobal(gdwCookie);
		if (pGIT)
		{
			pGIT -> Release();
			pGIT = NULL;
		}
		fprintf(fp, "CTestServer::RevokeInterfaceFromGlobal success\n");
		fclose(fp);
	}
	return hr;
}

STDMETHODIMP CTestServer::CallSimpleCallback(ICallbackTestServer *pparam, long *sid)
{
    FILE *fp;
	if( (fp=fopen("C:\\Test\\TestServer.log" , "at+")) != NULL )
    {
		fprintf(fp, "CTestServer::CallSimpleCallback entered\n");
		long session = 7;
	
		ICallbackTestServer *pCallbackTestServer;
		if (pparam != NULL){
			HRESULT hr=pparam->QueryInterface(IID_ICallbackTestServer,(void**) &pCallbackTestServer);
			if (hr == S_OK){
				pCallbackTestServer->PrintSession(session, sid);
				fprintf(fp, "CTestServer::CallSimpleCallback ==> pparam->PrintSession came back sesionIn=%d and sessionOut=%d\n", session, *sid);
			}
			else
				fprintf(fp, "CTestServer::CallSimpleCallback ==> failed to query interface HR=0x%x\n", hr);
		}
		fprintf(fp, "CTestServer::CallSimpleCallback leaving\n");
		fclose(fp);
	}
	return S_OK;
}

STDMETHODIMP CTestServer::UnDoSomethingAndGetSomethingBack(long lSessionID, unsigned long* pSessionId)
{
	FILE *fp;
	if( (fp=fopen("C:\\Test\\TestServer_thread.log" , "at+")) == NULL ){
		return MK_E_CANTOPENFILE;
	}
		// Caller provides the memory for the data
	*pSessionId = lSessionID;
	fprintf(fp, "CTestServer::UnDoSomethingAndGetSomethingBack. session is %d\n", lSessionID);
	fclose(fp);
	return S_OK;
}

STDMETHODIMP CTestServer::GetTCharArray(/*[out]*/ TCHAR* tcharArray[50])
{
	// TODO: Add your implementation code here
	FILE *fp;
	if( (fp=fopen("C:\\Test\\TestServer_thread.log" , "at+")) == NULL ){
		return MK_E_CANTOPENFILE;
	}
	fprintf(fp, "CTestServer::GetTCharArray\n");
	TCHAR* p = new TCHAR[50];
	for (int i=0; i<50; i++){
			p[i] = 'Z';
	}
	p[49] = '\0';
	*tcharArray = p;
	fprintf(fp, "GetTCharArray returned=%s\n", p);
	fclose(fp);
	return S_OK;
}

STDMETHODIMP CTestServer::SetTCharArray(/*[in]*/ TCHAR tcharArray[50])
{
	// TODO: Add your implementation code here
	FILE *fp;
	if( (fp=fopen("C:\\Test\\TestServer_thread.log" , "at+")) == NULL ){
		return MK_E_CANTOPENFILE;
	}
	fprintf(fp, "CTestServer::SetTCharArray\nData=");
		for (int i=0; i<50; i++){
			fprintf(fp, "%c ", tcharArray[i]);
		}
	fprintf(fp, "\n");
	fclose(fp);
	return S_OK;
}

STDMETHODIMP CTestServer::GetConformantIntArray(/*[out]*/ int* sizeOut, /*[out, size_is(,*sizeOut)]*/ int** intArray)
{
	FILE *fp;
	if( (fp=fopen("C:\\Test\\TestServer_thread.log" , "at+")) == NULL ){
		return MK_E_CANTOPENFILE;
	}

	int *Data = new int[20];
	*sizeOut = 20;
	*intArray = Data;
	for (int i=0; i<20; i++)
		Data[i] = i;
	fprintf(fp, "CTestServer::GetConformantIntArray ==> Sent array of size=20 back\n");
	fclose(fp);
	return S_OK;
}

STDMETHODIMP CTestServer::SetConformantIntArray(/*[in]*/ int size,/*[in, size_is(size)]*/ int intArray[])
{
	FILE *fp;
	if( (fp=fopen("C:\\Test\\TestServer.log" , "at+")) == NULL ){
		return MK_E_CANTOPENFILE;
	}
	fprintf(fp, "CTestServer::SetConformantIntArray\nSetConformantIntArray set=");
	for (int i=0; i<size; i++){
		fprintf(fp, "%d=%d ", i, intArray[i]);
	}
	fprintf(fp, "\n");
	fclose(fp);
	return S_OK;
}

STDMETHODIMP CTestServer::GetStruct(/*[out]*/ stStructA** param)
{
	FILE *fp;
	if( (fp=fopen("C:\\Test\\TestServer.log" , "at+")) == NULL ){
		return MK_E_CANTOPENFILE;
	}
	stStructA* Data = new stStructA;
	for(int j=0; j<50; j++)
		Data[0].param3[j] = 7;
    Data[0].param1 = 200;
    Data[0].param2 = 2.0;
	*param = Data;
	fprintf(fp, "CTestServer::GetStruct ==> Sent 1 struct back\n");
	fclose(fp);
	return S_OK;
}

STDMETHODIMP CTestServer::GetSimpleStruct(/*[out]*/ SimpleStruct** pSimpleStruct)
{
	FILE *fp;
	if( (fp=fopen("C:\\Test\\TestServer.log" , "at+")) == NULL ){
		return MK_E_CANTOPENFILE;
	}
	SimpleStruct* Data = new SimpleStruct;
	Data->l = 10;
	Data->f = 1.5;
	Data->d = 55;
	*pSimpleStruct = Data;
	fprintf(fp, "CTestServer::GetSimpleStruct ==> Sent 1 struct back\n");
	fclose(fp);
	return S_OK;
}

STDMETHODIMP CTestServer::GetConformantStructArray(unsigned short* isize,
													/*[out, size_is(,*isize)]*/ SimpleStruct** pSimple)
{
	FILE *fp;
	if( (fp=fopen("C:\\Test\\TestServer.log" , "at+")) == NULL ){
		return MK_E_CANTOPENFILE;
	}
	*isize = 3;
	SimpleStruct* Data = new SimpleStruct[*isize];
	for(int j=0; j<(*isize); j++){
		Data[j].l = 10;
		Data[j].f = 1.5;
		Data[j].d = 55;
	}
	*pSimple = Data;
	fprintf(fp, "CTestServer::GetConformantStructArray ==> Sent 3 structs back\n");
	fclose(fp);
	return S_OK;
}

STDMETHODIMP CTestServer::GetConformantStruct(/*[out]*/ ConformantStruct** ppConformantStruct)
{
	FILE *fp;
	if( (fp=fopen("C:\\Test\\TestServer.log" , "at+")) == NULL ){
		return MK_E_CANTOPENFILE;
	}
	ConformantStruct* Data = new ConformantStruct;
	Data->l = 10;
	Data->d = 55;
	Data->sz = 4;
	Data->pLong = new long[4];
	for (int i=0; i<4;i++){
		Data->pLong[i] = i+7;
	}
	*ppConformantStruct = Data;
	fprintf(fp, "CTestServer::GetConformantStruct ==> Sent 1 struct back\n");
	fclose(fp);
	return S_OK;
}

STDMETHODIMP CTestServer::SetStruct(/*[in]*/ stStructA param)
{
	FILE *fp;
	if( (fp=fopen("C:\\Test\\TestServer.log" , "at+")) == NULL ){
		return MK_E_CANTOPENFILE;
	}
	fprintf(fp, "CTestServer::SetStruct\nData=");
    fprintf(fp, "Id=%d and version=%f ", param.param1, param.param2);
	for (int i=0; i<50; i++){
		fprintf(fp,"%s ", param.param3[i]);
	}
	fprintf(fp, "\n");
	fclose(fp);
	return S_OK;
}

STDMETHODIMP CTestServer::GetStructArray2(/*[out]*/ unsigned short* isize,
								/*[out, size_is(isize)]*/ struct StructC** pparam){
	FILE *fp;
	if( (fp=fopen("C:\\Test\\TestServer.log" , "at+")) == NULL ){
		return MK_E_CANTOPENFILE;
	}
	*isize = 4;
	fprintf(fp, "CTestServer::GetStructArray2 with isize %d\n", *isize);
	struct StructC* Data = new struct StructC[*isize];
	for (int i=0; i<*isize; i++){
		Data[i].param1 = (unsigned long) i;
		Data[i].param2 = (unsigned long) i;
		Data[i].param3 = i+1;
		Data[i].param4 = new struct StructB[Data[i].param3];
		fprintf(fp,"StructC ==> param1=%u param2=%u array size=%d\n", Data[i].param1, Data[i].param2, Data[i].param3);
		for (int j=0; j<Data[i].param3; j++){
			Data[i].param4[j].param1 = (unsigned long) j;
			Data[i].param4[j].param2 = (float) 1.5;
			Data[i].param4[j].param3 = (float) 2.5;
			Data[i].param4[j].param4 = (unsigned short) 2;
			Data[i].param4[j].param5 = (float) j;
			Data[i].param4[j].param6 = (DATE) 10001+j*7;
			Data[i].param4[j].param7 = (unsigned long) j;
			fprintf(fp,"StructB ==> param1=%u param2=%f param4=%u and timstamtp=%e\n", Data[i].param4[j].param1, Data[i].param4[j].param2, Data[i].param4[j].param4, Data[i].param4[j].param6);
		}
	}
	*pparam = Data;
	fclose(fp);
	return S_OK;
}

STDMETHODIMP CTestServer::SetStructArray2(/*[in]*/ unsigned short isize,
									/*[in, size_is(isize)]*/ struct StructC * pparam){
	FILE *fp;
	if( (fp=fopen("C:\\Test\\TestServer.log" , "at+")) == NULL ){
		return MK_E_CANTOPENFILE;
	}
	fprintf(fp, "CTestServer::SetStructArray2 with isize %d\n", isize);
	for (int i=0; i<isize; i++){
		fprintf(fp,"StructC ==> param1=%u param2=%u array size=%d\n", pparam[i].param1, pparam[i].param2, pparam[i].param3);
		for (int j=0; j<pparam[i].param3; j++){
			fprintf(fp,"StructB ==> param1=%u param2=%f param4=%u and timstamtp=%e\n", pparam[i].param4[j].param1, pparam[i].param4[j].param2, pparam[i].param4[j].param4, pparam[i].param4[j].param6);
		}
	}
	fclose(fp);
	return S_OK;
}

STDMETHODIMP CTestServer::GetStructStruct(StructStruct** pp){

	FILE *fp;
	if( (fp=fopen("C:\\Test\\TestServer.log" , "at+")) == NULL ){
		return MK_E_CANTOPENFILE;
	}
	StructStruct* p = new StructStruct;
	p->l = 101;
	p->d = 555;

	ConformantStruct* Data = &(p->st);
	Data->d = 55;
	Data->l = 10;
	Data->sz = 4;
	Data->pLong = new long[4];
	for (int i=0; i<4;i++){
		Data->pLong[i] = i+7;
	}
	*pp = p;
	fprintf(fp, "CTestServer::GetStructStruct ==> Sent 1 struct back\n");
	fclose(fp);
	return S_OK;
}

STDMETHODIMP CTestServer::GetStructStructArray(unsigned short* isize,StructStruct** pp){
	FILE *fp;
	if( (fp=fopen("C:\\Test\\TestServer.log" , "at+")) == NULL ){
		return MK_E_CANTOPENFILE;
	}
	*isize = 4;
	StructStruct* pArray = new StructStruct[*isize];

	for (int i=0; i<*isize; i++){
		ConformantStruct* Data = &(pArray[i].st);
		Data->l = 10;
		Data->d = 55;
		Data->sz = 4;
		Data->pLong = new long[4];
		for (int j=0; j<4;j++){
			Data->pLong[j] = i+j+7;
		}
		pArray[i].l = 101;
		pArray[i].d = 555;
	}
	*pp = pArray;
	fprintf(fp, "CTestServer::GetStructStructArray ==> Sent 4 structs back\n");
	return S_OK;
}

STDMETHODIMP CTestServer::GetSimpleArrayStruct(SimpleArrayStruct** pp){
	FILE *fp;
	if( (fp=fopen("C:\\Test\\TestServer.log" , "at+")) == NULL ){
		return MK_E_CANTOPENFILE;
	}
	SimpleArrayStruct* Data = new SimpleArrayStruct;
	Data->l = 10;
	Data->d = 55;
	Data->sz = 4;
	Data->pSt = new SimpleStruct[4];
	for (int i=0; i<4;i++){
		Data->pSt[i].l = 100;
		Data->pSt[i].d = 555;
		Data->pSt[i].f = 4.5;
	}
	*pp = Data;
	fprintf(fp, "CTestServer::GetSimpleArrayStruct ==> Sent 1 struct back\n");
	return S_OK;
}

STDMETHODIMP CTestServer::GetSimpleArrayStructArray(unsigned short* isize,SimpleArrayStruct** pp){
	FILE *fp;
	if( (fp=fopen("C:\\Test\\TestServer.log" , "at+")) == NULL ){
		return MK_E_CANTOPENFILE;
	}
	*isize = 4;
	SimpleArrayStruct* pArray = new SimpleArrayStruct[*isize];

	for (int j=0; j<*isize; j++){
		pArray[j].l = 10+j;
		pArray[j].d = 55+j;
		pArray[j].sz = 4;
		pArray[j].pSt = new SimpleStruct[4];
		for (int i=0; i<4;i++){
			pArray[j].pSt[i].l = 100+i+j;
			pArray[j].pSt[i].d = 555+i+j;
			pArray[j].pSt[i].f = 4.5+i+j;
		}
	}
	*pp = pArray;
	fprintf(fp, "CTestServer::GetStructStructArray ==> Sent 4 structs back\n");
	fclose(fp);
	return S_OK;
}

STDMETHODIMP CTestServer::SetSimpleArrayStructArray(unsigned short isize,SimpleArrayStruct* pArray){
	FILE *fp;
	if( (fp=fopen("C:\\Test\\TestServer.log" , "at+")) == NULL ){
		return MK_E_CANTOPENFILE;
	}

	fprintf(fp, "CTestServer::SetSimpleArrayStructArray with isize %d\n", isize);
	for (int j=0; j<isize; j++){
		fprintf(fp,"SetSimpleArrayStructArray ==> l=%d d=%e array size=%d\n", pArray[j].l, pArray[j].d, pArray[j].sz);
		for (int i=0; i<pArray[j].sz;i++){
			fprintf(fp,"SetSimpleArrayStructArray ==> l=%d d=%e f=%f\n", pArray[j].pSt[i].l, pArray[j].pSt[i].d, pArray[j].pSt[i].f);
		}
	}
	fclose(fp);
	return S_OK;
}

STDMETHODIMP CTestServer::GetStructArray(/*[out]*/ unsigned short* isize,
								  /*[out, size_is(isize)]*/ struct StructC** p){
	FILE *fp;
	if( (fp=fopen("C:\\Test\\TestServer.log" , "at+")) == NULL ){
		return MK_E_CANTOPENFILE;
	}
	fprintf(fp, "CTestServer::GetStructArray with isize %d\n", isize);
	fclose(fp);
	return S_OK;
}

STDMETHODIMP CTestServer::SetStructArray(/*[in]*/ unsigned short isize,
									/*[in, size_is(isize)]*/ struct StructC * p){
	FILE *fp;
	if( (fp=fopen("C:\\Test\\TestServer.log" , "at+")) == NULL ){
		return MK_E_CANTOPENFILE;
	}
	struct StructC * pparam = p;
	fprintf(fp, "CTestServer::SetStructArray with isize %d\n", isize);
	for (int i=0; i<isize; i++){
		fprintf(fp,"StructC ==> param1=%u param2=%u array size=%d\n", pparam[i].param1, pparam[i].param2, pparam[i].param3);
		for (int j=0; j<pparam[i].param3; j++){
			fprintf(fp,"StructB ==> param1=%u param2=%f param4=%u and timstamtp=%e\n", pparam[i].param4[j].param1, pparam[i].param4[j].param2, pparam[i].param4[j].param4, pparam[i].param4[j].param6);
		}
	}
	fclose(fp);
	return S_OK;
}

