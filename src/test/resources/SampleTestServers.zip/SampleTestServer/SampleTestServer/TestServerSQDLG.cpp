// TestServerSQDLG.cpp : Implementation of CTestServerSQDLG
#include "stdafx.h"
#include "TestServerSQDLG.h"

/////////////////////////////////////////////////////////////////////////////
// CTestServerSQDLG
