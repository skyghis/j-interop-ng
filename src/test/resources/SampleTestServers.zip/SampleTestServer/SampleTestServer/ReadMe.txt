CODE CONTRIBUTED BY A USER
--------------------------


Please make sure c:\\test folder is present on your HDD. This project has been compiled with Visual Studio
Express Edition (2005). And has strong dependency on SampleTestServer2 project accompanying this distribution.
Please make sure you compile that one first. Also SampleTestServer.h is generated during compilation of this project,
it may give a compilation error during the first compile run. It looks for SampleTestServer2.h in it's folder
and cannot find it. Please

Replace
#include "SampleTestServer2.h"

with
#include "../../SampleTestServer2/SampleTestServer2/SampleTestServer2.h"

Do not copy the SampleTestServer2.h to this projects local folder. This one is also generated when SampleTestServer2 is compiled.

Another thing, Compile SampleTestServer first (after SampleTestServer2) and then the SampleTestServerProxy.
Register all projects (and their proxies) manually using RegSvr32.

RegSvr32 SampleTestServer2.dll
RegSvr32 SampleTestServer2Proxy.dll
RegSvr32 SampleTestServer.dll
RegSvr32 SampleTestServerProxy.dll

That's it ! Use the SampleTestServer.java to access this project.
