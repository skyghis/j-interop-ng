// CallbackTestServer.h : Declaration of the CCallbackTestServer

#ifndef __CallbackTestServer_H_
#define __CallbackTestServer_H_

#include "resource.h"       // main symbols


/////////////////////////////////////////////////////////////////////////////
// CCallbackTestServer
class ATL_NO_VTABLE CCallbackTestServer :
//	public CComObjectRootEx<CComSingleThreadModel>,
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CCallbackTestServer, &CLSID_CallbackTestServer>,
	public ICallbackTestServer,
	public ITestSink

{
public:
	CCallbackTestServer()
	{
	}
public:
	short val;

DECLARE_REGISTRY_RESOURCEID(IDR_CallbackTestServer)
DECLARE_NOT_AGGREGATABLE(CCallbackTestServer)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CCallbackTestServer)
	COM_INTERFACE_ENTRY(ICallbackTestServer)
	COM_INTERFACE_ENTRY(ITestSink)
END_COM_MAP()

// ICallbackTestServer
public:
   STDMETHOD(PrintSession)(
			long sid, long* param);
   //IDynamicSync
   STDMETHOD(UpdateStructC)(/* in */ long sid,
						/* in */ unsigned short unsize,
						/* [in,size_is(unsize) ] */	stStructA arrayOfStructA[]);

// ITestSink
   STDMETHOD(UpdateMe)(/*[in]*/ unsigned short length,
						/*[in, size_is(isize)]*/ struct StructC * param);

};

#endif //__CallbackTestServer_H_
