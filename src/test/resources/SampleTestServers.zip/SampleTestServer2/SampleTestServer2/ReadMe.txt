Please follow instructions as per the Readme.txt of SampleTestServer sln. This project can be Built using
Visual Studio Express Edition (2005).