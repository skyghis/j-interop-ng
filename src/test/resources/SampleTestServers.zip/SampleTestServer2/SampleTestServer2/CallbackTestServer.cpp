// CallbackTestServer.cpp : Implementation of CCallbackTestServer
#include <iostream>
#include "stdafx.h"
#include "SampleTestServer2.h"
#include "CallbackTestServer.h"
#include <comdef.h>


/////////////////////////////////////////////////////////////////////////////
// CCallbackTestServer


STDMETHODIMP CCallbackTestServer::PrintSession(long sid, long* sidOut)
{
	// TODO: Add your implementation code here
    FILE *fp;
	if( (fp=fopen("C:\\Test\\callback.log" , "at+")) != NULL )
    {
		*sidOut = (sid+10);
		fprintf(fp, "CCallbackTestServer::PrintSession. sessionIn is %d and sessionOut=%d\n", sid, *sidOut);
		fclose(fp);
	}
	return S_OK;
}

STDMETHODIMP CCallbackTestServer::UpdateStructC(long sid, unsigned short unsize, stStructA structA[])
{
	// TODO: Add your implementation code here
    FILE *fp;
	if( (fp=fopen("C:\\Test\\callback.log" , "at+")) != NULL )
    {
		fprintf(fp, "CCallbackTestServer::UpdateStructC with session %d\n", sid);
		for (int i=0; i<unsize; i++){
			fprintf(fp, "id for %d is=%d and version is=%f and data is:\n", i, structA[i].param1, structA[i].param2);
			for (int j=0; j<50;j++)
				fprintf(fp, "%d", structA[i].param3[j]);
			fprintf (fp, "\n");
		}
	fclose(fp);
	}
	return S_OK;
}



STDMETHODIMP CCallbackTestServer::UpdateMe(/*[in]*/ unsigned short isize,
									   /*[in, size_is(isize)]*/ struct StructC * pparam)
{
    FILE *fp;
	if( (fp=fopen("C:\\Test\\callback.log" , "at+")) != NULL )
    {
		fprintf(fp, "CCallbackTestServer::UpdateMe with isize %d\n", isize);
		for (int i=0; i<isize; i++){
			fprintf(fp,"StructC ==> param1=%u param2=%u array size=%d\n", pparam[i].param1, pparam[i].param2, pparam[i].param3);
			for (int j=0; j<pparam[i].param3; j++){
				fprintf(fp,"StructB ==> param1=%u param2=%f param4=%u and timstamtp=%e\n", pparam[i].param4[j].param1, pparam[i].param4[j].param2, pparam[i].param4[j].param4, pparam[i].param4[j].param6);
			}
		}
		fclose(fp);
	}
	return S_OK;
}